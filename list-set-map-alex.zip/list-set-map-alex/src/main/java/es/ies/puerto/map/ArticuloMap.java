package es.ies.puerto.map;


import java.util.HashMap;
import java.util.Map;

import es.ies.puerto.Articulo;

public class ArticuloMap {
    Map<String, Articulo> articulos;

    /**
     * Constructor general.
     */
    public ArticuloMap() {
        this.articulos = new HashMap<>();
    }

    /**
     * Agrega un articulo si este no se encuentra en el mapa.
     * @param articulo a agregar al mapa.
     * @return true si el articulo fue agregado.
     */
    public boolean agregar(Articulo articulo) {
        if(articulo == null) return false;
        if(!articulos.containsValue(articulo)) return false;
        articulos.put(articulo.getCodigo(), articulo);
        return true;
    }

    /**
     * Lista los articulos que se encuentran en el mapa.
     * @return los articulos del mapa.
     */
    public Map<String, Articulo> listar() {
        return new HashMap<>(articulos);
    }

    /**
     * 
     * @param codigo
     * @return
     */
    public Articulo buscar(String codigo) {
            return null;
    }

    public boolean actualizar(String codigo, Articulo nuevoArticulo) {
        return false;
    }

    public boolean eliminar(String codigo) {
        return false;
    }
}
