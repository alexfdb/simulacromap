package es.ies.puerto.list;

import java.util.ArrayList;
import java.util.List;

import es.ies.puerto.*;

public class AnimalList {
    private List<Animal> animales;

    public AnimalList() {
        this.animales = new ArrayList<>();
    }

    /**
     * Agrega un animal a la lista si este no se encuentra en ella.
     * @param animal a agregar.
     * @return true si el animal fue agregado.
     */
    public boolean agregar(Animal animal) {
        if (!animales.contains(animal)) {
            return animales.add(animal);
        }
        return false;
    }

    /**
     * Lista los animales.
     * @return los animales de la lista.
     */
    public List<Animal> listar() {
        return new ArrayList<>(animales);
    }

    /**
     * Busca un animal en la lista por su identificador.
     * @param identificador del animal.
     * @return el animal o en su defecto null.
     */
    public Animal buscar(String identificador) {
        return animales.stream()
                .filter(a -> a.getIdentificador().equals(identificador))
                .findFirst()
                .orElse(null);
    }

    /**
     * Actualiza un animal de la lista si este se encuentra en ella.
     * @param identificador del animal a actualizar.
     * @param nuevoAnimal a actualizar.
     * @return true si el animal fue actualizado.
     */
    public boolean actualizar(String identificador, Animal nuevoAnimal) {
        Animal buscar = new Animal(identificador);
        int posicion = animales.indexOf(buscar);
        if (posicion < 0) {
            return false;
        }
        animales.set(posicion, nuevoAnimal);
        return true;
    }

    /**
     * Elimina una animal de la lista por medio de su identificador.
     * @param identificador del animal a eliminar.
     * @return true si el animal fue eliminado.
     */
    public boolean eliminar(String identificador) {
        Animal animalEliminar = new Animal(identificador);
        return animales.remove(animalEliminar);
    }

}
